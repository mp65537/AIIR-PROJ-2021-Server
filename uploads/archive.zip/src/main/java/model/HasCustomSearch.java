package model;

public interface HasCustomSearch {
}
